#!/usr/bin/env python3
"""Build-time source patch for SideStore v14 protocol matrix.

The iOS 26.4+ RemotePairing control channel is reachable through EMProxy at
10.7.0.1:49152, but the dynamic createListener port is frequently bound to a
specific native interface/address.  This patch:

* adds Apple's CoreDeviceService peerConnectionsInfo to createListener;
* forces RP-only transport (no misleading 62078 Lockdown probe first);
* creates a fresh PairVerify + listener for every dynamic endpoint candidate;
* tries scoped IPv6, interface-bound IPv6/IPv4, source-bound, loopback,
  local-utun, and the existing virtual-reflection route;
* emits deterministic diagnostics without logging pairing keys;
* prints FLAG: READY_TO_AUTOMATION only after a real refresh succeeds.
"""
from __future__ import annotations

from pathlib import Path
import sys

MARKER = "[SS-V14-PROTOCOL]"
READY = "FLAG: READY_TO_AUTOMATION"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        fail(f"{label}: expected exactly one anchor, found {count}")
    return text.replace(old, new, 1)


def patch_remote_pairing(path: Path) -> None:
    text = path.read_text()
    if "owningProcessName\": \"CoreDeviceService" in text and "SS-V14-CREATE-LISTENER" in text:
        return

    old = '''                    "createListener": {
                        "key": base64::engine::general_purpose::STANDARD.encode(&self.encryption_key),
                        "transportProtocolType": "tcp"
                    }
'''
    new = '''                    "createListener": {
                        "key": base64::engine::general_purpose::STANDARD.encode(&self.encryption_key),
                        // Xcode/CoreDeviceService includes this metadata.  On newer iOS
                        // builds the listener may be created but not made reachable when
                        // the peer identity is omitted.
                        "peerConnectionsInfo": [{
                            "owningPID": std::process::id() as u64,
                            "owningProcessName": "CoreDeviceService"
                        }],
                        "transportProtocolType": "tcp"
                    }
'''
    text = replace_once(text, old, new, "createListener peer metadata")

    old_log = '        debug!("createListener response: {response:#?}");\n'
    new_log = '''        debug!("createListener response: {response:#?}");
        tracing::error!("[SS-V14-CREATE-LISTENER] response_received peer_info=true");
'''
    text = replace_once(text, old_log, new_log, "createListener response marker")
    path.write_text(text)


RUST_HELPERS = r'''

// -------------------------------------------------------------------------
// SideStore v14: native dynamic-listener endpoint matrix
// -------------------------------------------------------------------------
#[derive(Clone, Debug)]
struct V14DynamicCandidate {
    label: String,
    destination: std::net::IpAddr,
    scope_id: u32,
    interface_index: u32,
    bind_interface: bool,
    bind_source: Option<std::net::IpAddr>,
    // true = connect the 49152 control channel to this same native host.
    // false = keep the proven 10.7.0.1 reflected control channel and use
    // this candidate only for the dynamic listener.
    native_control: bool,
}

#[derive(Clone, Debug)]
struct V14InterfaceAddress {
    name: String,
    address: std::net::IpAddr,
    scope_id: u32,
    interface_index: u32,
}

#[cfg(unix)]
fn v14_interface_addresses() -> Vec<V14InterfaceAddress> {
    use std::ffi::CStr;
    use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

    let mut result = Vec::new();
    let mut head: *mut libc::ifaddrs = std::ptr::null_mut();
    if unsafe { libc::getifaddrs(&mut head) } != 0 || head.is_null() {
        tracing::error!("[SS-V14-PROTOCOL] IFACE_ENUM_FAILED errno={}", std::io::Error::last_os_error());
        return result;
    }

    let mut cursor = head;
    while !cursor.is_null() {
        let ifa = unsafe { &*cursor };
        cursor = ifa.ifa_next;
        if ifa.ifa_name.is_null() || ifa.ifa_addr.is_null() {
            continue;
        }
        if (ifa.ifa_flags & (libc::IFF_UP as u32)) == 0 {
            continue;
        }

        let name = unsafe { CStr::from_ptr(ifa.ifa_name) }
            .to_string_lossy()
            .into_owned();
        let interface_index = unsafe { libc::if_nametoindex(ifa.ifa_name) };
        let family = unsafe { (*ifa.ifa_addr).sa_family as i32 };

        let (address, scope_id) = if family == libc::AF_INET {
            let sin = unsafe { &*(ifa.ifa_addr as *const libc::sockaddr_in) };
            let host_order = u32::from_be(sin.sin_addr.s_addr);
            (IpAddr::V4(Ipv4Addr::from(host_order)), 0)
        } else if family == libc::AF_INET6 {
            let sin6 = unsafe { &*(ifa.ifa_addr as *const libc::sockaddr_in6) };
            let bytes = sin6.sin6_addr.s6_addr;
            let ip = Ipv6Addr::from(bytes);
            let scope = if ip.is_unicast_link_local() {
                if sin6.sin6_scope_id != 0 { sin6.sin6_scope_id } else { interface_index }
            } else {
                sin6.sin6_scope_id
            };
            (IpAddr::V6(ip), scope)
        } else {
            continue;
        };

        if address.is_unspecified() || address.is_multicast() {
            continue;
        }
        result.push(V14InterfaceAddress {
            name,
            address,
            scope_id,
            interface_index,
        });
    }

    unsafe { libc::freeifaddrs(head) };
    result
}

#[cfg(not(unix))]
fn v14_interface_addresses() -> Vec<V14InterfaceAddress> {
    Vec::new()
}

fn v14_candidate_key(candidate: &V14DynamicCandidate) -> String {
    format!(
        "{}|{}|{}|{}|{}|{:?}|{}",
        candidate.label,
        candidate.destination,
        candidate.scope_id,
        candidate.interface_index,
        candidate.bind_interface,
        candidate.bind_source,
        candidate.native_control
    )
}

fn v14_push_unique(
    candidates: &mut Vec<V14DynamicCandidate>,
    seen: &mut std::collections::HashSet<String>,
    candidate: V14DynamicCandidate,
) {
    let key = v14_candidate_key(&candidate);
    if seen.insert(key) {
        candidates.push(candidate);
    }
}

fn v14_build_candidates(control_addr: std::net::SocketAddr) -> Vec<V14DynamicCandidate> {
    use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

    let interfaces = v14_interface_addresses();
    for iface in &interfaces {
        tracing::error!(
            "[SS-V14-PROTOCOL] IFACE name={} index={} address={} scope={}",
            iface.name,
            iface.interface_index,
            iface.address,
            iface.scope_id
        );
    }

    let mut candidates = Vec::new();
    let mut seen = std::collections::HashSet::new();

    // First isolate the smallest possible fix: keep the proven reflected
    // control/data path, but send the complete Apple peer metadata.
    v14_push_unique(&mut candidates, &mut seen, V14DynamicCandidate {
        label: "virtual-reflection".into(),
        destination: control_addr.ip(),
        scope_id: match control_addr {
            std::net::SocketAddr::V6(v6) => v6.scope_id(),
            _ => 0,
        },
        interface_index: 0,
        bind_interface: false,
        bind_source: None,
        native_control: false,
    });

    // Build an Apple-parity matrix.  Apple's clients use one physical host for
    // both the PairVerify control channel and the returned listener port.  We
    // also retain a hybrid route (reflected control, native dynamic endpoint)
    // because the 49152 reflection is already proven on this device.
    let mut en0_v6: Vec<&V14InterfaceAddress> = interfaces
        .iter()
        .filter(|x| x.name == "en0" && matches!(x.address, IpAddr::V6(_)))
        .collect();
    en0_v6.sort_by_key(|x| match x.address {
        IpAddr::V6(ip) if ip.is_unicast_link_local() => 0,
        _ => 1,
    });
    for iface in en0_v6.into_iter().take(2) {
        for (suffix, native_control, bind_source) in [
            ("samehost-bound-if", true, None),
            ("virtual-control-native-dynamic", false, None),
            ("samehost-bound-source", true, Some(iface.address)),
        ] {
            v14_push_unique(&mut candidates, &mut seen, V14DynamicCandidate {
                label: format!("en0-v6-{suffix}"),
                destination: iface.address,
                scope_id: iface.scope_id,
                interface_index: iface.interface_index,
                bind_interface: true,
                bind_source,
                native_control,
            });
        }
    }

    if let Some(iface) = interfaces
        .iter()
        .find(|x| x.name == "en0" && matches!(x.address, IpAddr::V4(_)))
    {
        for (suffix, native_control, bind_source, bind_interface) in [
            ("samehost-bound-if", true, None, true),
            ("virtual-control-native-dynamic", false, None, true),
            ("samehost-native", true, None, false),
            ("samehost-bound-source", true, Some(iface.address), true),
        ] {
            v14_push_unique(&mut candidates, &mut seen, V14DynamicCandidate {
                label: format!("en0-v4-{suffix}"),
                destination: iface.address,
                scope_id: 0,
                interface_index: iface.interface_index,
                bind_interface,
                bind_source,
                native_control,
            });
        }
    }

    // If remoted associated the listener with the tunnel-facing address, a
    // direct socket to the local utun address is different from packet swapping.
    for iface in interfaces
        .iter()
        .filter(|x| x.name.starts_with("utun"))
        .take(2)
    {
        for (suffix, native_control) in [
            ("samehost-native", true),
            ("virtual-control-native-dynamic", false),
        ] {
            v14_push_unique(&mut candidates, &mut seen, V14DynamicCandidate {
                label: format!("{}-{suffix}", iface.name),
                destination: iface.address,
                scope_id: iface.scope_id,
                interface_index: iface.interface_index,
                bind_interface: false,
                bind_source: None,
                native_control,
            });
        }
    }

    // Apple Wireless Direct Link / low-latency Wi-Fi can carry peer services.
    if let Some(iface) = interfaces.iter().find(|x| {
        (x.name == "awdl0" || x.name == "llw0") && matches!(x.address, IpAddr::V6(_))
    }) {
        v14_push_unique(&mut candidates, &mut seen, V14DynamicCandidate {
            label: format!("{}-v6-samehost-bound-if", iface.name),
            destination: iface.address,
            scope_id: iface.scope_id,
            interface_index: iface.interface_index,
            bind_interface: true,
            bind_source: None,
            native_control: true,
        });
    }

    for (label, address) in [
        ("loopback-v6-samehost", IpAddr::V6(Ipv6Addr::LOCALHOST)),
        ("loopback-v4-samehost", IpAddr::V4(Ipv4Addr::LOCALHOST)),
    ] {
        v14_push_unique(&mut candidates, &mut seen, V14DynamicCandidate {
            label: label.into(),
            destination: address,
            scope_id: 0,
            interface_index: 0,
            bind_interface: false,
            bind_source: None,
            native_control: true,
        });
    }

    // The virtual-reflection baseline was inserted first so a metadata-only
    // fix wins immediately; the remaining routes are fallbacks.

    candidates.truncate(20);
    candidates
}

#[cfg(any(target_os = "ios", target_os = "macos", target_os = "tvos", target_os = "visionos"))]
fn v14_bind_socket_to_interface(
    socket: &tokio::net::TcpSocket,
    address: std::net::IpAddr,
    interface_index: u32,
) -> std::io::Result<()> {
    use std::os::fd::AsRawFd;

    if interface_index == 0 {
        return Ok(());
    }
    let fd = socket.as_raw_fd();
    let index = interface_index as libc::c_uint;
    let (level, option): (libc::c_int, libc::c_int) = match address {
        std::net::IpAddr::V4(_) => (libc::IPPROTO_IP, 25),       // IP_BOUND_IF
        std::net::IpAddr::V6(_) => (libc::IPPROTO_IPV6, 125),  // IPV6_BOUND_IF
    };
    let rc = unsafe {
        libc::setsockopt(
            fd,
            level,
            option,
            &index as *const _ as *const libc::c_void,
            std::mem::size_of_val(&index) as libc::socklen_t,
        )
    };
    if rc == 0 { Ok(()) } else { Err(std::io::Error::last_os_error()) }
}

#[cfg(not(any(target_os = "ios", target_os = "macos", target_os = "tvos", target_os = "visionos")))]
fn v14_bind_socket_to_interface(
    _socket: &tokio::net::TcpSocket,
    _address: std::net::IpAddr,
    _interface_index: u32,
) -> std::io::Result<()> {
    Ok(())
}

fn v14_socket_addr(candidate: &V14DynamicCandidate, port: u16) -> std::net::SocketAddr {
    match candidate.destination {
        std::net::IpAddr::V4(ip) => std::net::SocketAddr::V4(std::net::SocketAddrV4::new(ip, port)),
        std::net::IpAddr::V6(ip) => std::net::SocketAddr::V6(std::net::SocketAddrV6::new(
            ip,
            port,
            0,
            candidate.scope_id,
        )),
    }
}

async fn v14_connect_dynamic(
    candidate: &V14DynamicCandidate,
    port: u16,
) -> Result<tokio::net::TcpStream, IdeviceError> {
    use tokio::net::TcpSocket;

    let socket = match candidate.destination {
        std::net::IpAddr::V4(_) => TcpSocket::new_v4(),
        std::net::IpAddr::V6(_) => TcpSocket::new_v6(),
    }
    .map_err(IdeviceError::Socket)?;

    if candidate.bind_interface {
        v14_bind_socket_to_interface(&socket, candidate.destination, candidate.interface_index)
            .map_err(|e| IdeviceError::InternalError(format!("bind interface: {e}")))?;
    }

    if let Some(source) = candidate.bind_source {
        let bind_addr = match source {
            std::net::IpAddr::V4(ip) => {
                std::net::SocketAddr::V4(std::net::SocketAddrV4::new(ip, 0))
            }
            std::net::IpAddr::V6(ip) => {
                std::net::SocketAddr::V6(std::net::SocketAddrV6::new(
                    ip,
                    0,
                    0,
                    candidate.scope_id,
                ))
            }
        };
        socket
            .bind(bind_addr)
            .map_err(|e| IdeviceError::InternalError(format!("bind source {bind_addr}: {e}")))?;
    }

    let destination = v14_socket_addr(candidate, port);
    let stream = tokio::time::timeout(
        std::time::Duration::from_millis(1200),
        socket.connect(destination),
    )
    .await
    .map_err(|_| IdeviceError::InternalError(format!("connect timeout: {destination}")))?
    .map_err(IdeviceError::Socket)?;
    let _ = stream.set_nodelay(true);
    Ok(stream)
}

async fn v14_finish_connected_stream(
    tunnel_stream: tokio::net::TcpStream,
    encryption_key: &[u8],
) -> Result<(idevice::tcp::handle::AdapterHandle, RsdHandshake), IdeviceError> {
    use idevice::remote_pairing::connect_tls_psk_tunnel_native;

    let tunnel = tokio::time::timeout(
        std::time::Duration::from_secs(4),
        connect_tls_psk_tunnel_native(tunnel_stream, encryption_key),
    )
    .await
    .map_err(|_| IdeviceError::InternalError("TLS/CDTunnel timeout".into()))??;

    let client_ip: std::net::IpAddr = tunnel
        .info
        .client_address
        .parse()
        .map_err(|e| IdeviceError::InternalError(format!("client IP: {e}")))?;
    let server_ip: std::net::IpAddr = tunnel
        .info
        .server_address
        .parse()
        .map_err(|e| IdeviceError::InternalError(format!("server IP: {e}")))?;
    let mtu = tunnel.info.mtu as usize;
    let rsd_port = tunnel.info.server_rsd_port;

    let raw = tunnel.into_inner();
    let mut adapter = idevice::tcp::adapter::Adapter::new(Box::new(raw), client_ip, server_ip);
    adapter.set_mss(mtu.saturating_sub(60));
    let mut adapter = adapter.to_async_handle();
    let rsd_stream = tokio::time::timeout(
        std::time::Duration::from_secs(3),
        adapter.connect(rsd_port),
    )
    .await
    .map_err(|_| IdeviceError::InternalError("RSD TCP timeout".into()))?
    .map_err(|e| IdeviceError::InternalError(format!("RSD TCP: {e}")))?;
    let handshake = tokio::time::timeout(
        std::time::Duration::from_secs(3),
        RsdHandshake::new(rsd_stream),
    )
    .await
    .map_err(|_| IdeviceError::InternalError("RSD handshake timeout".into()))??;
    Ok((adapter, handshake))
}
'''

RPP_FUNCTION = r'''#[unsafe(no_mangle)]
pub unsafe extern "C" fn tunnel_create_rppairing(
    addr: *const idevice_sockaddr,
    addr_len: idevice_socklen_t,
    hostname: *const c_char,
    pairing_file: *mut RpPairingFileHandle,
    pin_callback: Option<extern "C" fn(context: *mut c_void) -> *const c_char>,
    pin_context: *mut c_void,
    out_adapter: *mut *mut AdapterHandle,
    out_handshake: *mut *mut RsdHandshakeHandle,
) -> *mut IdeviceFfiError {
    if addr.is_null()
        || hostname.is_null()
        || pairing_file.is_null()
        || out_adapter.is_null()
        || out_handshake.is_null()
    {
        return ffi_err!(IdeviceError::FfiInvalidArg);
    }

    let control_addr = match crate::util::c_socket_to_rust(addr as *const SockAddr, addr_len) {
        Ok(a) => a,
        Err(e) => return ffi_err!(e),
    };
    let host = match unsafe { CStr::from_ptr(hostname) }.to_str() {
        Ok(s) => s.to_string(),
        Err(_) => return ffi_err!(IdeviceError::FfiInvalidString),
    };
    let rpf = unsafe { &mut (*pairing_file).0 };
    let ctx = PinCtx(pin_context);

    let res = run_sync_local(async {
        let candidates = v14_build_candidates(control_addr);
        tracing::error!(
            "[SS-V14-PROTOCOL] MATRIX_START control={} candidates={} fresh_pairverify_per_candidate=true",
            control_addr,
            candidates.len()
        );
        let mut failures: Vec<String> = Vec::new();

        for (index, candidate) in candidates.iter().enumerate() {
            tracing::error!(
                "[SS-V14-PROTOCOL] ATTEMPT_START index={} label={} destination={} scope={} ifindex={} bind_if={} bind_source={:?} native_control={}",
                index,
                candidate.label,
                candidate.destination,
                candidate.scope_id,
                candidate.interface_index,
                candidate.bind_interface,
                candidate.bind_source,
                candidate.native_control
            );

            // A createListener is tied to the verified control session.  Never
            // reuse a listener across endpoint candidates.
            let selected_control = if candidate.native_control {
                v14_socket_addr(candidate, control_addr.port())
            } else {
                control_addr
            };
            let control_stream = if candidate.native_control {
                v14_connect_dynamic(candidate, control_addr.port()).await
            } else {
                match tokio::time::timeout(
                    std::time::Duration::from_secs(2),
                    tokio::net::TcpStream::connect(control_addr),
                )
                .await
                {
                    Ok(Ok(stream)) => {
                        let _ = stream.set_nodelay(true);
                        Ok(stream)
                    }
                    Ok(Err(error)) => Err(IdeviceError::Socket(error)),
                    Err(_) => Err(IdeviceError::InternalError("control connect timeout".into())),
                }
            };
            let control_stream = match control_stream {
                Ok(stream) => stream,
                Err(error) => {
                    failures.push(format!("{}:control:{error}", candidate.label));
                    tracing::error!(
                        "[SS-V14-PROTOCOL] CONTROL_CONNECT_FAIL label={} endpoint={} error={}",
                        candidate.label,
                        selected_control,
                        error
                    );
                    continue;
                }
            };
            tracing::error!(
                "[SS-V14-PROTOCOL] CONTROL_CONNECT_PASS label={} endpoint={} mode={}",
                candidate.label,
                selected_control,
                if candidate.native_control { "same-native-host" } else { "virtual-reflection" }
            );

            let conn = RpPairingSocket::new(control_stream);
            let mut rpc = RemotePairingClient::new(conn, &host);
            if let Err(error) = rpc.connect(rpf, async || get_pin(pin_callback, &ctx)).await {
                failures.push(format!("{}:pairverify:{error}", candidate.label));
                tracing::error!("[SS-V14-PROTOCOL] PAIRING_FAIL label={} error={}", candidate.label, error);
                continue;
            }
            tracing::error!("[SS-V14-PROTOCOL] PAIRING_PASS label={}", candidate.label);

            let listener_port = match tokio::time::timeout(
                std::time::Duration::from_secs(2),
                rpc.create_tcp_listener(),
            )
            .await
            {
                Ok(Ok(port)) => port,
                Ok(Err(error)) => {
                    failures.push(format!("{}:listener:{error}", candidate.label));
                    tracing::error!("[SS-V14-PROTOCOL] LISTENER_FAIL label={} error={}", candidate.label, error);
                    continue;
                }
                Err(_) => {
                    failures.push(format!("{}:listener:timeout", candidate.label));
                    tracing::error!("[SS-V14-PROTOCOL] LISTENER_FAIL label={} error=timeout", candidate.label);
                    continue;
                }
            };
            tracing::error!(
                "[SS-V14-PROTOCOL] LISTENER_PASS label={} port={} peer_info=true",
                candidate.label,
                listener_port
            );

            // Give remoted one scheduler turn to publish the new listener.
            tokio::time::sleep(std::time::Duration::from_millis(40)).await;
            tracing::error!(
                "[SS-V14-PROTOCOL] DYNAMIC_CONNECT_START label={} endpoint={}",
                candidate.label,
                v14_socket_addr(candidate, listener_port)
            );
            let dynamic_stream = match v14_connect_dynamic(candidate, listener_port).await {
                Ok(stream) => stream,
                Err(error) => {
                    failures.push(format!("{}:dynamic:{error}", candidate.label));
                    tracing::error!("[SS-V14-PROTOCOL] DYNAMIC_CONNECT_FAIL label={} error={}", candidate.label, error);
                    continue;
                }
            };
            tracing::error!("[SS-V14-PROTOCOL] DYNAMIC_CONNECT_PASS label={}", candidate.label);

            let encryption_key = rpc.encryption_key().to_vec();
            tracing::error!("[SS-V14-PROTOCOL] TLS_CDTUNNEL_START label={}", candidate.label);
            match v14_finish_connected_stream(dynamic_stream, &encryption_key).await {
                Ok((adapter, handshake)) => {
                    tracing::error!("[SS-V14-PROTOCOL] TLS_PASS label={}", candidate.label);
                    tracing::error!("[SS-V14-PROTOCOL] CDTUNNEL_PASS label={}", candidate.label);
                    tracing::error!("[SS-V14-PROTOCOL] RSD_PASS label={}", candidate.label);
                    tracing::error!("[SS-V14-READY] TRANSPORT_PASS route={}", candidate.label);
                    return Ok::<_, IdeviceError>((adapter, handshake));
                }
                Err(error) => {
                    failures.push(format!("{}:tls-cdtunnel-rsd:{error}", candidate.label));
                    tracing::error!("[SS-V14-PROTOCOL] TLS_CDTUNNEL_RSD_FAIL label={} error={}", candidate.label, error);
                }
            }
        }

        let summary = failures.into_iter().take(16).collect::<Vec<_>>().join(" | ");
        Err::<(idevice::tcp::handle::AdapterHandle, RsdHandshake), IdeviceError>(
            IdeviceError::InternalError(format!("v14 dynamic endpoint matrix exhausted: {summary}"))
        )
    });

    match res {
        Ok((adapter, handshake)) => {
            write_result(adapter, handshake, out_adapter, out_handshake);
            null_mut()
        }
        Err(e) => ffi_err!(e),
    }
}

'''


def patch_ffi(path: Path) -> None:
    text = path.read_text()
    if MARKER in text and "v14_build_candidates" in text:
        return

    insert_anchor = '''/// Creates a tunnel over the network via raw RPPairing protocol.
'''
    if text.count(insert_anchor) != 1:
        fail("FFI helper insertion anchor drift")
    text = text.replace(insert_anchor, RUST_HELPERS + "\n" + insert_anchor, 1)

    fn_start = text.find('#[unsafe(no_mangle)]\npub unsafe extern "C" fn tunnel_create_rppairing(')
    fn_end = text.find('/// The peer device identity learned during a successful pair-setup.', fn_start)
    if fn_start < 0 or fn_end < 0:
        fail("FFI tunnel_create_rppairing boundaries not found")
    text = text[:fn_start] + RPP_FUNCTION + text[fn_end:]
    path.write_text(text)


def patch_gateway(path: Path) -> None:
    text = path.read_text()
    if "TRANSPORT_SELECT path=v14-rp-protocol-matrix" in text:
        return

    start = text.find("    private func ensureRPConnection() throws {")
    end = text.find("    private func isPairingError", start)
    if start < 0 or end < 0:
        fail("IdeviceGateway ensureRPConnection boundaries not found")

    replacement = r'''    private func ensureRPConnection() throws {
        debugLog(
            "[SS-V14-PROTOCOL] CONNECTION_START adapter_ready=\(adapter != nil) " +
            "handshake_ready=\(handshake != nil)"
        )
        if adapter != nil && handshake != nil {
            debugLog("[SS-V14-PROTOCOL] CONNECTION_REUSE_PASS")
            return
        }

        invalidateConnection()
        guard let deviceEndpointIp, !deviceEndpointIp.isEmpty else {
            throw IdeviceGatewayError(.connectionFailed, reason: "Device endpoint IP is not configured")
        }
        guard hasRemotePairingCapability else {
            throw IdeviceGatewayError(
                .invalidPairingFile,
                reason: "v14 requires RemotePairing credentials in the imported pairing file"
            )
        }

        // 62078 is excluded from the primary path.  The protocol matrix starts
        // with the proven 49152 PairVerify control channel and selects the dynamic
        // endpoint using a fresh listener for every candidate.
        debugLog("[SS-V14-PROTOCOL] TRANSPORT_SELECT path=v14-rp-protocol-matrix control=\(deviceEndpointIp):\(remotePairingPort)")
        var failures: [String] = []
        do {
            try ensureExactRemotePairingFallback(deviceEndpointIp: deviceEndpointIp)
            guard adapter != nil, handshake != nil else {
                throw IdeviceGatewayError(
                    .connectionFailed,
                    reason: "v14 protocol matrix returned no RSD transport"
                )
            }
            debugLog("[SS-V14-READY] TRANSPORT_PASS gateway=idevice route=remote-pairing-matrix")
            return
        } catch {
            invalidateConnection()
            failures.append("RemotePairing matrix: \(error.localizedDescription)")
            debugLog("[SS-V14-PROTOCOL] MATRIX_FAILED reason=\(error.localizedDescription)")
        }

        // Exhaustive last resort.  The device previously reset QueryType on
        // 62078, but keeping this after the RP matrix costs nothing on the happy
        // path and preserves a second independent Apple transport.
        if hasLockdownCapability {
            debugLog("[SS-V14-PROTOCOL] COREDEVICE_FALLBACK_START endpoint=\(deviceEndpointIp):\(MinimuxerConstants.lockdowndPort)")
            do {
                try ensureCoreDeviceProxyConnection(deviceEndpointIp: deviceEndpointIp)
                guard adapter != nil, handshake != nil else {
                    throw IdeviceGatewayError(
                        .connectionFailed,
                        reason: "CoreDevice fallback returned no RSD transport"
                    )
                }
                debugLog("[SS-V14-PROTOCOL] COREDEVICE_FALLBACK_PASS")
                debugLog("[SS-V14-READY] TRANSPORT_PASS gateway=idevice route=coredevice-fallback")
                return
            } catch {
                invalidateConnection()
                failures.append("CoreDevice fallback: \(error.localizedDescription)")
                debugLog("[SS-V14-PROTOCOL] COREDEVICE_FALLBACK_FAIL reason=\(error.localizedDescription)")
            }
        }

        throw IdeviceGatewayError(
            .connectionFailed,
            reason: failures.joined(separator: " | ")
        )
    }

'''
    text = text[:start] + replacement + text[end:]
    path.write_text(text)


def patch_refresh(path: Path) -> None:
    text = path.read_text()
    if READY in text:
        return
    old = '''        self.setProgress(100)
        return installedApp
'''
    new = '''        self.setProgress(100)
        // This marker is intentionally emitted only after the complete refresh
        // pipeline has produced profiles, installed them, and committed the
        // refreshed app state. Transport-only success must never set readiness.
        debugLog("[SS-V14-READY] SIGNER_PASS bundle=\\(installedApp.bundleIdentifier)")
        debugLog("FLAG: READY_TO_AUTOMATION")
        return installedApp
'''
    text = replace_once(text, old, new, "refresh success marker")
    path.write_text(text)


def verify(remote: str, ffi: str, gateway: str, refresh: str) -> None:
    requirements = {
        "remote pairing": ["peerConnectionsInfo", "owningProcessName\": \"CoreDeviceService", "SS-V14-CREATE-LISTENER"],
        "ffi": [MARKER, "fresh_pairverify_per_candidate=true", "IP_BOUND_IF", "IPV6_BOUND_IF", "virtual-reflection", "PAIRING_PASS", "LISTENER_PASS", "DYNAMIC_CONNECT_PASS", "RSD_PASS"],
        "gateway": ["TRANSPORT_SELECT path=v14-rp-protocol-matrix", "v14 requires RemotePairing", "[SS-V14-READY] TRANSPORT_PASS"],
        "refresh": ["[SS-V14-READY] SIGNER_PASS", READY],
    }
    blobs = {"remote pairing": remote, "ffi": ffi, "gateway": gateway, "refresh": refresh}
    for name, required in requirements.items():
        missing = [token for token in required if token not in blobs[name]]
        if missing:
            fail(f"{name} verification missing {missing}")

    if "TRANSPORT_SELECT path=existing-lockdown-coredevice-proxy" in gateway[gateway.find("private func ensureRPConnection"):gateway.find("private func isPairingError")]:
        fail("gateway still selects CoreDeviceProxy inside ensureRPConnection")
    if refresh.count(READY) != 1:
        fail("READY_TO_AUTOMATION must exist exactly once")


def main() -> None:
    if len(sys.argv) != 5:
        fail("usage: patch_v14_protocol_matrix.py <remote_pairing/mod.rs> <ffi/tunnel_provider.rs> <IdeviceGateway.swift> <RefreshAppOperation.swift>")
    remote_path, ffi_path, gateway_path, refresh_path = map(Path, sys.argv[1:])
    patch_remote_pairing(remote_path)
    patch_ffi(ffi_path)
    patch_gateway(gateway_path)
    patch_refresh(refresh_path)
    verify(
        remote_path.read_text(),
        ffi_path.read_text(),
        gateway_path.read_text(),
        refresh_path.read_text(),
    )
    print("v14 protocol matrix patch applied and verified")


if __name__ == "__main__":
    main()
